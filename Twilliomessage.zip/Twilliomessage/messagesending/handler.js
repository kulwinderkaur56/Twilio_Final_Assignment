const twilioAccountSid = "twilioAccountSid";
const twilioAuthToken = "twilioAuthToken";
const twilioPhoneNumber = "twilioPhoneNumber";
const twilioClient = require('twilio')(twilioAccountSid, twilioAuthToken);


module.exports.sendText = (context, callback) => {
  // use twilio SDK to send text message
  const sms = {
    to: "your phone number",
    body: "image has been uploaded",
    from: "Twilio phone number",
  };
  // add image to sms if supplied
  
    // sms.mediaUrl = "https://s3.amazonaws.com/messagesend/img1.jpg";
  
  twilioClient.messages.create(sms, (error, data) => { // eslint-disable-line
    if (error) {
      const errResponse = {
        headers: {
          'Access-Control-Allow-Origin': '*', // Required for CORS support to work
        },
        statusCode: error.status,
        body: JSON.stringify({
          message: error.message,
          error: error // eslint-disable-line
        }),
      };
      return callback(null, errResponse);
    }
    // text message sent! ✅
    // console.log(`message: ${data.body}`); // eslint-disable-line
    // console.log(`date_created: ${data.date_created}`); // eslint-disable-line

    const response = {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*', // Required for CORS support to work
      },
      body: JSON.stringify({
        message: 'Text message successfully sent!',
        data: data // eslint-disable-line
      }),
    };

    callback(null, response);
  });
};
